<template>
  <div class="about">
    <h2>
      About Page
    </h2>
  </div>
</template>

<script>
export default {
  name: 'about'
}
</script>
