<template>
  <div class="about">
    <h2>
      Galería
    </h2>
  </div>
</template>

<script>
export default {
  name: 'galeria'
}
</script>
